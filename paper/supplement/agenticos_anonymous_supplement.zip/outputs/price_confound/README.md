# Observed model-label cost-propensity adjustment

This table residualizes log total dollar cost using displayed-model-label and benchmark fixed effects. It tests sensitivity of raw cost-rank transfer to stable observed label-level cost propensity. It is not a list-price adjustment and is not a causal execution-dynamics estimate because the frozen CSV lacks provider alias, token components, and historical price-card data.
